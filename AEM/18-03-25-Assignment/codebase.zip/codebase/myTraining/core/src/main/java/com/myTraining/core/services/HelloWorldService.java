package com.myTraining.core.services;



public interface HelloWorldService {
    String getMessage();
}
